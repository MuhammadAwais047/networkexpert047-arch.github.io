# Gaming Lobby Website - Project Outline

## File Structure
```
/output/
├── index.html              # Main landing page with hero, live match ticker
├── blog.html               # Loadout blog with filterable cards
├── gear.html               # Gear reviews with performance meters
├── guild.html              # Guild recruitment with Discord integration
├── main.js                 # Core JavaScript functionality
└── resources/              # Assets folder
    ├── hero-bg.jpg         # Hero background image
    ├── gaming-gear/        # Gear review images
    ├── team-logos/         # Esports team logos
    └── particle-texture.png # Particle effect texture
```

## Page Breakdown

### index.html - Gaming Lobby Hub
- **Pre-loader**: 8-bit health bar animation
- **Hero Section**: Full-screen gaming setup with animated elements
- **Live Match Ticker**: Real-time esports scores with team colors
- **Quick Navigation**: Access to all site sections
- **Interactive Elements**: Kill feed widget, particle effects

### blog.html - Loadout Blog
- **Filter System**: Patch notes, meta, esports, hardware tags
- **Blog Cards**: Hover effects with CRT distortion
- **Content Categories**: Sortable by gaming topics
- **Search Functionality**: Find specific articles

### gear.html - Gear Reviews
- **Review Grid**: Gaming peripherals and hardware
- **DPS Meter**: Price-to-performance visualization
- **Rating System**: Star ratings with Google schema
- **Filter Options**: By category, price, rating

### guild.html - Guild Recruitment
- **Discord Integration**: OAuth login simulation
- **Squad Filters**: Region, rank, roles, mic requirements
- **Recruitment Cards**: Open squad listings
- **Quick Join**: One-click Discord server integration

## Interactive Features
- **Particle System**: Ambient drifting particles responding to mouse
- **Kill Feed**: Live updating kill notifications
- **Hover Effects**: 3D transforms and glow effects
- **Scroll Animations**: GSAP-powered reveals
- **Easter Eggs**: Konami code, godmode terminal

## Visual Effects
- **Scan Lines**: Subtle overlay texture
- **Neon Glows**: Cyan, red, gold accent colors
- **CRT Distortion**: Magnetic effects on hover
- **Shimmer Animations**: Gradient button effects
- **Parallax Scrolling**: Background elements