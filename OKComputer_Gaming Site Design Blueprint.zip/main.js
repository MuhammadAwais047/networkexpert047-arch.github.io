// Gaming Lobby Website - Main JavaScript
// Core functionality for dark-neon gaming theme

class GamingLobby {
    constructor() {
        this.particles = [];
        this.killFeed = [];
        this.matches = [];
        this.init();
    }

    init() {
        this.setupParticles();
        this.setupKillFeed();
        this.setupLiveMatches();
        this.setupScrollAnimations();
        this.setupEasterEggs();
        this.setupPreloader();
    }

    // Preloader with 8-bit health bar
    setupPreloader() {
        const preloader = document.createElement('div');
        preloader.className = 'preloader fixed inset-0 bg-gray-900 z-50 flex items-center justify-center';
        preloader.innerHTML = `
            <div class="text-center">
                <div class="health-bar-container w-64 h-8 bg-gray-800 border-2 border-cyan-400 relative overflow-hidden">
                    <div class="health-bar-fill h-full bg-gradient-to-r from-red-500 to-cyan-400 transition-all duration-1200 ease-out" style="width: 0%"></div>
                </div>
                <p class="text-cyan-400 font-rajdhani mt-4 text-lg tracking-wider">LOADING LOBBY...</p>
            </div>
        `;
        document.body.appendChild(preloader);

        setTimeout(() => {
            const healthBar = preloader.querySelector('.health-bar-fill');
            healthBar.style.width = '100%';
            
            setTimeout(() => {
                preloader.style.opacity = '0';
                setTimeout(() => preloader.remove(), 500);
            }, 1200);
        }, 500);
    }

    // Particle system for ambient effects
    setupParticles() {
        const canvas = document.createElement('canvas');
        canvas.className = 'particle-canvas fixed inset-0 pointer-events-none z-0';
        canvas.style.opacity = '0.3';
        document.body.appendChild(canvas);

        const ctx = canvas.getContext('2d');
        this.resizeCanvas(canvas);
        this.createParticles(canvas, ctx);

        window.addEventListener('resize', () => this.resizeCanvas(canvas));
        canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e, canvas));
    }

    resizeCanvas(canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    createParticles(canvas, ctx) {
        for (let i = 0; i < 50; i++) {
            this.particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                size: Math.random() * 2 + 1,
                opacity: Math.random() * 0.5 + 0.2
            });
        }
        this.animateParticles(canvas, ctx);
    }

    animateParticles(canvas, ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        this.particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;

            if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
            if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(0, 245, 255, ${particle.opacity})`;
            ctx.fill();
        });

        requestAnimationFrame(() => this.animateParticles(canvas, ctx));
    }

    handleMouseMove(e, canvas) {
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        this.particles.forEach(particle => {
            const dx = mouseX - particle.x;
            const dy = mouseY - particle.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 100) {
                particle.vx += dx * 0.00005;
                particle.vy += dy * 0.00005;
            }
        });
    }

    // Kill feed system
    setupKillFeed() {
        const killFeedContainer = document.getElementById('killFeed');
        if (!killFeedContainer) return;

        const fakeKills = [
            {killer: 'Phoenix', weapon: 'AK-47', victim: 'Ghost'},
            {killer: 'Nova', weapon: 'AWP', victim: 'Reaper'},
            {killer: 'Blaze', weapon: 'M4A4', victim: 'Shadow'},
            {killer: 'Viper', weapon: 'Desert Eagle', victim: 'Ronin'},
            {killer: 'Ghost', weapon: 'AWP', victim: 'Phoenix'}
        ];

        let killIndex = 0;
        
        const addKill = () => {
            const kill = fakeKills[killIndex % fakeKills.length];
            const killElement = document.createElement('li');
            killElement.className = 'kill-item opacity-0 transform translate-x-full transition-all duration-500';
            killElement.innerHTML = `
                <span class="killer text-cyan-400 font-bold">${kill.killer}</span>
                <span class="weapon text-yellow-400 mx-2">${kill.weapon}</span>
                <span class="victim text-red-400">${kill.victim}</span>
            `;
            
            killFeedContainer.prepend(killElement);
            
            setTimeout(() => {
                killElement.classList.remove('opacity-0', 'translate-x-full');
            }, 100);
            
            setTimeout(() => {
                killElement.style.opacity = '0.4';
            }, 5000);
            
            setTimeout(() => {
                killElement.remove();
            }, 7000);
            
            killIndex++;
        };

        // Add kills periodically
        setInterval(addKill, 3000);
        addKill(); // Add first kill immediately
    }

    // Live match ticker
    setupLiveMatches() {
        const matchContainer = document.getElementById('liveMatches');
        if (!matchContainer) return;

        const mockMatches = [
            {team1: 'FaZe Clan', team2: 'NAVI', score1: 16, score2: 14, status: 'Live'},
            {team1: 'Astralis', team2: 'Vitality', score1: 12, score2: 8, status: 'Live'},
            {team1: 'G2 Esports', team2: 'Fnatic', score1: 0, score2: 0, status: 'Upcoming'},
            {team1: 'Team Liquid', team2: 'Complexity', score1: 2, score2: 1, status: 'Completed'}
        ];

        mockMatches.forEach(match => {
            const matchCard = document.createElement('div');
            matchCard.className = 'match-card bg-gray-800 border-l-4 border-cyan-400 p-4 rounded-r-lg hover:bg-gray-750 transition-colors';
            matchCard.innerHTML = `
                <div class="flex justify-between items-center">
                    <div class="flex-1">
                        <div class="flex justify-between items-center mb-2">
                            <span class="team-name font-rajdhani text-lg">${match.team1}</span>
                            <span class="score font-bold text-xl text-cyan-400">${match.score1}</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="team-name font-rajdhani text-lg">${match.team2}</span>
                            <span class="score font-bold text-xl text-cyan-400">${match.score2}</span>
                        </div>
                    </div>
                    <div class="ml-4">
                        <span class="status ${match.status === 'Live' ? 'text-red-400' : match.status === 'Upcoming' ? 'text-yellow-400' : 'text-green-400'} font-bold">
                            ${match.status}
                        </span>
                    </div>
                </div>
            `;
            matchContainer.appendChild(matchCard);
        });
    }

    // Scroll animations
    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe elements with scroll animation
        document.querySelectorAll('.scroll-animate').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    }

    // Easter eggs
    setupEasterEggs() {
        // Konami code
        let konamiCode = [];
        const konamiSequence = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65]; // ↑↑↓↓←→←→BA

        document.addEventListener('keydown', (e) => {
            konamiCode.push(e.keyCode);
            if (konamiCode.length > konamiSequence.length) {
                konamiCode.shift();
            }

            if (konamiCode.join(',') === konamiSequence.join(',')) {
                this.activateVaporwaveMode();
                konamiCode = [];
            }
        });

        // Godmode terminal
        let godmodeInput = '';
        document.addEventListener('keypress', (e) => {
            godmodeInput += e.key;
            if (godmodeInput.includes('/godmode')) {
                this.showTerminal();
                godmodeInput = '';
            }
            if (godmodeInput.length > 20) {
                godmodeInput = godmodeInput.slice(-8);
            }
        });
    }

    activateVaporwaveMode() {
        document.documentElement.style.setProperty('--primary-cyan', '#ff00ff');
        document.documentElement.style.setProperty('--primary-red', '#00ffff');
        document.documentElement.style.setProperty('--primary-gold', '#ff00ff');
        
        // Play chiptune (simulated with console log)
        console.log('🎵 Vaporwave mode activated! Playing chiptune...');
        
        setTimeout(() => {
            document.documentElement.style.setProperty('--primary-cyan', '#00F5FF');
            document.documentElement.style.setProperty('--primary-red', '#FF004C');
            document.documentElement.style.setProperty('--primary-gold', '#FFB800');
        }, 5000);
    }

    showTerminal() {
        const terminal = document.createElement('div');
        terminal.className = 'terminal fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center';
        terminal.innerHTML = `
            <div class="terminal-window bg-gray-900 border-2 border-green-400 p-8 max-w-2xl w-full">
                <div class="terminal-header flex justify-between items-center mb-4">
                    <span class="text-green-400 font-mono">GODMODE TERMINAL</span>
                    <button class="close-terminal text-red-400 hover:text-red-300">[X]</button>
                </div>
                <div class="terminal-body font-mono text-green-400">
                    <div class="terminal-line">> System initialized...</div>
                    <div class="terminal-line">> Access level: ADMIN</div>
                    <div class="terminal-line">> Available commands:</div>
                    <div class="terminal-line ml-4">- /stats (show player stats)</div>
                    <div class="terminal-line ml-4">- /config (edit settings)</div>
                    <div class="terminal-line ml-4">- /hidden (unlock secrets)</div>
                    <div class="terminal-line">> _</div>
                </div>
            </div>
        `;
        
        document.body.appendChild(terminal);
        
        terminal.querySelector('.close-terminal').addEventListener('click', () => {
            terminal.remove();
        });
    }
}

// Button interactions
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-raid')) {
        e.target.style.transform = 'translateY(-2px)';
        e.target.style.boxShadow = '0 8px 24px rgba(0,245,255,.55)';
        
        setTimeout(() => {
            e.target.style.transform = 'translateY(0)';
            e.target.style.boxShadow = 'none';
        }, 150);
    }
});

// Copy to clipboard functionality
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        const notification = document.createElement('div');
        notification.className = 'copy-notification fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg z-50 transform translate-x-full transition-transform';
        notification.textContent = 'Copied!';
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.remove('translate-x-full'), 100);
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => notification.remove(), 300);
        }, 2000);
    });
}

// Initialize the gaming lobby when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new GamingLobby();
});

// Export for use in other files
window.GamingLobby = GamingLobby;
window.copyToClipboard = copyToClipboard;